<footer>
    <h4>FOOTER HAMADA</h4>
</footer>
<?php /**PATH /var/www/laravel-8/resources/views/hamada/parts/footer.blade.php ENDPATH**/ ?>