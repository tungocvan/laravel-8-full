<?php
    //dd($data['data']);
?>
<?php if(session('msg')): ?>
    <div class="alert alert-outline-success mt-2"><?php echo e(session('msg')); ?></div>
<?php endif; ?> 

<div class="row py-2">
    <div class="col-6 mt-2">
        <h3>Danh sách nhóm</h3>
        <a class="btn btn-primary mt-2" href="<?php echo e(route('modules.add')); ?>">Thêm mới</a> 
    </div>
</div>
<hr />
<table class="table">
  <thead>
    <tr>             
         <th>ID</th>
         <th>Module Name</th>
         <th>Description</th>
         <th>Action</th>
         
    </tr>
  </thead>
  <tbody>
    <?php if(count($data['data']) > 0): ?>
      <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>             
        <td><?php echo e($item['id']); ?></td>
        <td><?php echo e($item['name']); ?></td>
        <td><?php echo e($item['title']); ?></td>        
        <td>
          <div class="row">   
              <div class="col-4"><a class="btn btn-success" href="<?php echo e(route('modules.edit',$item)); ?>">Sửa</a></div>
              <div class="col-4"><a class="btn btn-danger" href="<?php echo e(route('modules.post-delete',$item['id'])); ?>">Xóa</a></div>
          </div>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
  </tbody>
</table>
<script>        
    document.addEventListener('DOMContentLoaded', function(event) {
        
    });
</script><?php /**PATH /home1/nhathhmd/public_html/laravel/demo/modules/Modules/Resources/views/phoenix/parts/modules-content.blade.php ENDPATH**/ ?>