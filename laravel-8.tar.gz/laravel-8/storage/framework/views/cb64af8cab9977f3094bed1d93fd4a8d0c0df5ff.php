<?php
    $number = (string) rand(100,999);
    $title = $options['title'] ?? '' ;
    $name = $options['name'] ?? 'name-'.$number;
    $selected = $options['selected'] ?? 'Open this select menu';
    $multiple = $options['multiple'] ?? '';
    $selectArray =$options['select'] ?? [['value' => '1','title' => 'One'],['value' => '2','title' => 'Two']];
    $value = $options['value'] ?? ''; 
?>
<div class="mb-2" style="padding: 5px">
    <?php if($title !==''): ?>
            <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($title); ?></label>
    <?php endif; ?>
    <select class="form-select" aria-label="Default select" name="<?php echo e($name); ?>[]" <?php echo e($multiple?'multiple':''); ?>>
        <?php if($selected =='Open this select menu'): ?>
            <option selected>Open this select menu</option>
        <?php endif; ?>
        <?php $__currentLoopData = $selectArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option <?php echo e($item['value'] ==  $selected?'selected':''); ?> value="<?php echo e($item['value']); ?>"><?php echo e($item['title']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div><?php /**PATH /var/www/laravel-8/resources/views/components/input-select.blade.php ENDPATH**/ ?>