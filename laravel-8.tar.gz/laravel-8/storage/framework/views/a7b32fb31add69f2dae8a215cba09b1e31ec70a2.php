<?php
    $category = $data['category'];    
    $parent = $data['parent'] ?? 0; 
    $options = [
        'name' => [
            'name' => 'title',
            'title' => 'Thêm tiêu đề'            
        ],
        'avatar' => [
            'name' => 'thumnail',
        ],
];
?>
<h4 class="my-4">THÊM BÀI VIẾT</h4>
<form method="POST" action="<?php echo e(route('post.post-add')); ?>">
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="row">
            <div class="col-8">
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['name']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\editor::class, []); ?>
<?php $component->withName('editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732)): ?>
<?php $component = $__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732; ?>
<?php unset($__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732); ?>
<?php endif; ?>
                <hr />
                <div class="d-flex mb-3">
                    <a href="<?php echo e(route('post.index')); ?>" class="btn btn-phoenix-primary me-2 px-6">Hủy</a>
                    <button class="btn btn-primary" type="submit">Lưu bài viết</button>
                </div>
            </div>
            <div class="col-4">
                <h4 class="my-4">Chuyên mục</h4>
                <div class="scrollable-div">
                   <?php echo getCategoriesPost(['data' => $category,  'parent' => $parent]); ?>

                </div>
                <h4 class="my-4">Ảnh đại diện</h4>
                <?php if (isset($component)) { $__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputFile::class, ['options' => $options['avatar']]); ?>
<?php $component->withName('input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105)): ?>
<?php $component = $__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105; ?>
<?php unset($__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105); ?>
<?php endif; ?> 
            </div>
        </div>
    </div>
</form>
<?php $__env->startSection('jsHead'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('jsHead'); ?>
<script src="/plugin/ckeditor/ckeditor.js"></script>
<script src="/plugin/flatpickr/dist/flatpickr.min.js"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home1/nhathhmd/public_html/laravel/demo/modules/Post/Resources/views/phoenix/parts/add-content.blade.php ENDPATH**/ ?>