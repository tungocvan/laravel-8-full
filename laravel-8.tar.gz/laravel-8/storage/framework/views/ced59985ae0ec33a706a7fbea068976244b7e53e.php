<?php
  $options = ['id' => 'editor2'];
  $txtName = ['placeholder' => 'full name..'];

?>
<?php $__env->startSection('jsHead'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('jsHead'); ?>
<script src="/plugin/ckeditor/ckeditor.js"></script>
<script src="/plugin/flatpickr/dist/flatpickr.min.js"></script>
<?php $__env->stopSection(); ?>
<h4>MAIN HAMADA</h4>
<?php if (isset($component)) { $__componentOriginalb9120bacf0e229dc241d64cbff6ed42b644cec4c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UploadFile::class, []); ?>
<?php $component->withName('upload-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9120bacf0e229dc241d64cbff6ed42b644cec4c)): ?>
<?php $component = $__componentOriginalb9120bacf0e229dc241d64cbff6ed42b644cec4c; ?>
<?php unset($__componentOriginalb9120bacf0e229dc241d64cbff6ed42b644cec4c); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, []); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
<div class="container">
    <div class="row">
        <div class="col-6">
           <?php if (isset($component)) { $__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\editor::class, []); ?>
<?php $component->withName('editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732)): ?>
<?php $component = $__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732; ?>
<?php unset($__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732); ?>
<?php endif; ?>
        </div>        
      
        <div class="col-6">
           <?php if (isset($component)) { $__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\editor::class, ['options' => $options]); ?>
<?php $component->withName('editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732)): ?>
<?php $component = $__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732; ?>
<?php unset($__componentOriginal62c9d06a9f43b894e693a9196b851fb8ea02f732); ?>
<?php endif; ?>
        </div>        
      
    </div>
    <div class="row">        
        <div class="col-3">
          <?php if (isset($component)) { $__componentOriginalf9961231e6756a9f223d2f8a2f0942f2e9035364 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputDate::class, []); ?>
<?php $component->withName('input-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9961231e6756a9f223d2f8a2f0942f2e9035364)): ?>
<?php $component = $__componentOriginalf9961231e6756a9f223d2f8a2f0942f2e9035364; ?>
<?php unset($__componentOriginalf9961231e6756a9f223d2f8a2f0942f2e9035364); ?>
<?php endif; ?>
        </div>
        <div class="col-3">
          <?php if (isset($component)) { $__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputFile::class, []); ?>
<?php $component->withName('input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105)): ?>
<?php $component = $__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105; ?>
<?php unset($__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105); ?>
<?php endif; ?>
        </div>
        <div class="col-3">
          <?php if (isset($component)) { $__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputFile::class, []); ?>
<?php $component->withName('input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105)): ?>
<?php $component = $__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105; ?>
<?php unset($__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105); ?>
<?php endif; ?>
        </div>
    </div>
</div>

<?php /**PATH /var/www/laravel-8/resources/views/hamada/parts/main.blade.php ENDPATH**/ ?>