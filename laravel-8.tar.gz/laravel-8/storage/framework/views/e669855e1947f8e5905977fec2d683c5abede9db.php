<?php   
  // stringFormatDate($data['user']->birthday,'d/m/Y')
  $options = [
    'name' => [
        'name' => 'name',
        'title' => 'Họ và tên',
        'value' => $data['user']->name
    ],
    'email' => [
        'name' => 'email',
        'title' => 'Địa chỉ email',
        'value' => $data['user']->email,
        'disable' => true
    ],
    'birthday' => [
        'name' => 'birthday',
        'title' => 'Sinh nhật',      
        'value' => stringFormatDate($data['user']->birthday,'d/m/Y')
    ],
    'phone' => [
        'name' => 'phone',
        'title' => 'Số điện thoại',
        'value' => $data['user']->phone
    ],
    'password' => [
        'name' => 'password',
        'title' => 'Mật khẩu',
        'type' => 'password',
        'value' => $data['user']->password
    ],
    'avatar' => [
        'value' => $data['user']->avatar,
    ]
];  

?>
<form method="POST" action="<?php echo e(route('users.post-edit',$data['user']->id)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="d-sm-flex justify-content-between mt-4">
                    <h2 class="mb-4">Sửa thông tin thành viên</h2>                
                </div>
                <hr />
            </div>
        </div>
        
        <div class="row">
            <div class="col-3">            
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['name']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>                
                <?php if (isset($component)) { $__componentOriginalf9961231e6756a9f223d2f8a2f0942f2e9035364 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputDate::class, ['options' => $options['birthday']]); ?>
<?php $component->withName('input-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9961231e6756a9f223d2f8a2f0942f2e9035364)): ?>
<?php $component = $__componentOriginalf9961231e6756a9f223d2f8a2f0942f2e9035364; ?>
<?php unset($__componentOriginalf9961231e6756a9f223d2f8a2f0942f2e9035364); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['phone']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['email']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['password']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>                
            </div>
            <div class="col-3">
                <h4 class="mt-4">Ảnh đại diện</h4>   
                <?php if (isset($component)) { $__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputFile::class, ['options' => $options['avatar']]); ?>
<?php $component->withName('input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105)): ?>
<?php $component = $__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105; ?>
<?php unset($__componentOriginal805a841563fa5bb889fc4b4a319ce95905ff7105); ?>
<?php endif; ?>      
            </div>
        </div>
        <hr />
        <div class="d-flex mb-3">
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-phoenix-primary me-2 px-6">Hủy</a>
            <button class="btn btn-primary" type="submit">Cập nhật</button>
        </div>
        
    </div>
</form>
<?php /**PATH /home1/nhathhmd/public_html/laravel/demo/modules/Users/Resources/views/phoenix/parts/edit-content.blade.php ENDPATH**/ ?>