<header>
    <?php if(auth()->guard()->guest()): ?>
        <?php if(Route::has('login')): ?>
        <div class="nav-item">
            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Đăng nhập')); ?></a>
        </div>
        <?php endif; ?> 
    <?php else: ?>
         <h4>Xin chào! <?php echo e(Auth::user()->name); ?></h4>
         <div class="nav-item">
            <a href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                <?php echo e(__('Đăng xuất')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    <?php endif; ?>
           
</header><?php /**PATH /home1/nhathhmd/public_html/laravel/demo/resources/views/hamada/parts/header.blade.php ENDPATH**/ ?>