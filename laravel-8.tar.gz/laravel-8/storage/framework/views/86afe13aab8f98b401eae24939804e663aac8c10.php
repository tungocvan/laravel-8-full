<?php
  //dd($data['module']);
  $options = [
    'name' => [
        'name' => 'name',
        'title' => 'Tên Module',
        'value' => $data['module']->name
    ],
    'description' => [
        'name' => 'description',
        'title' => 'Mô tả chức năng Module',
        'value' => $data['module']->title
    ],   
];  

?>
<form method="POST" action="<?php echo e(route('modules.post-edit',$data['module']->id)); ?>">
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="d-sm-flex justify-content-between mt-4">
                    <h2 class="mb-4">Cập nhật lại Module</h2>                
                </div>
                <hr />
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">            
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['name']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['description']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>    
                
            </div>
        </div>
        <hr />
        <div class="d-flex mb-3">
            <button class="btn btn-phoenix-primary me-2 px-6">Hủy</button>
            <button class="btn btn-primary" type="submit">Cập nhật</button>
        </div>
        
    </div>
</form>
<?php /**PATH /var/www/laravel-8/modules/Modules/Resources/views/phoenix/parts/edit-content.blade.php ENDPATH**/ ?>