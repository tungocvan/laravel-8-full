<footer>
    <h4>FOOTER HAMADA</h4>
</footer>
<?php /**PATH /home1/nhathhmd/public_html/laravel/demo/resources/views/hamada/parts/footer.blade.php ENDPATH**/ ?>