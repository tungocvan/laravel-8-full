<?php    
    // https://flatpickr.js.org/examples/
     $number = (string) rand(10,99);
     $name = $options['name'] ?? 'name_'.$number;
     $id =   $options['id'] ?? $name;
     $title= $options['title'] ?? '' ;
     $placeholder = $options['placeholder'] ?? $title ;      
     $value = $options['value'] ?? '';    
     if($value === '01/01/1970') $value='';      
     $format = $options['format'] ?? "d/m/Y";     
?>
<div class="flatpickr-input-container mb-2">       
    <input <?php if($value!==''): ?> value=<?php echo e($value); ?> <?php endif; ?>  type="text" name="<?php echo e($name); ?>" id="<?php echo e($id); ?>" class="form-control ps-6 datetimepicker flatpickr flatpickr-input" placeholder="<?php echo e($placeholder  ?? 'Select Date'); ?>" />      
    <span class="far fa-calendar-plus flatpickr-icon" style="top:58%"></span>
</div>
<?php $__env->startSection('jsFooter'); ?> 
<?php echo \Illuminate\View\Factory::parentPlaceholder('jsFooter'); ?>
<script>
    $('.flatpickr-input').flatpickr({        
        dateFormat: "<?php echo e($format); ?>",
        allowInput:true
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/laravel-8/resources/views/components/input-date.blade.php ENDPATH**/ ?>