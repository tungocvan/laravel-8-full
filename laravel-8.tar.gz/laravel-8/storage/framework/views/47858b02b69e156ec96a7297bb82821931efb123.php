
<?php         
     $number = (string) rand(10,99);
     $name = $options['name'] ?? 'filepath';
     $id =   $options['id'] ?? $name.'_'.$number;
     $value = $options['value'] ?? '';
?>
<div class='row mb-3'> 
<div class='input-group'>
    <span class='input-group-btn'>
      <a id='<?php echo e($id); ?>' data-input='thumbnail_<?php echo e($id); ?>' data-preview='holder_<?php echo e($id); ?>' class='btn btn-primary flm'>
        <i class='fa fa-picture-o'></i> Choose
      </a>
    </span>
    <input id='thumbnail_<?php echo e($id); ?>' class='form-control' type='text' name='<?php echo e($name); ?>[]' <?php if($value !==''): ?> value=<?php echo e($value); ?>  <?php endif; ?> >
  </div>
<div id='holder_<?php echo e($id); ?>' style='margin-top:15px;max-height:100px;'>
      <?php if($value): ?>
          <img src="<?php echo e($value); ?>" style="height: 5rem;">
      <?php endif; ?>
</div>      
</div>
<?php $__env->startSection('jsFooter'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('jsFooter'); ?>
<script src='/vendor/laravel-filemanager/js/stand-alone-button.js'></script>
<script>
    $('.flm').filemanager('image');
</script>
<?php $__env->stopSection(); ?>


<?php /**PATH /home1/nhathhmd/public_html/laravel/demo/resources/views/components/input-file.blade.php ENDPATH**/ ?>