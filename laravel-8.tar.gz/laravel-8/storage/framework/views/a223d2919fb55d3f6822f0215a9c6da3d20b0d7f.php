<form action="/api/upload-file" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="file">
    <button type="submit">Upload</button>
</form><?php /**PATH /var/www/laravel-8/resources/views/components/upload-file.blade.php ENDPATH**/ ?>