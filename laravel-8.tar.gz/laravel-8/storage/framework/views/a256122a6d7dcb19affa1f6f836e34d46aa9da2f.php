<?php
  $styleBasic = $options['style'] ?? false;
  $id = $options['id'] ?? 'editor1';
  $name = $options['name'] ?? $id;
  $row = $options['rows'] ?? 10;
  $cols =$options['cols'] ?? 80;
  $content = $options['content'] ?? 'Ckeditor' ;
?>
<div class="py-2">
    <textarea name=<?php echo e($name); ?>  id=<?php echo e($id); ?> rows=<?php echo e($row); ?> cols=<?php echo e($cols); ?>>
        <?php echo e($content); ?>

    </textarea>
</div>

<?php $__env->startSection('jsHead'); ?> 
  <?php echo \Illuminate\View\Factory::parentPlaceholder('jsHead'); ?>
  
<?php $__env->stopSection(); ?>


<?php if($styleBasic): ?>
<script>
  // Replace the <textarea id="editor1"> with a CKEditor 4
  // instance, using default configuration.
  // https://ckeditor.com/docs/ckeditor4/latest/examples/removeformat.html
  CKEDITOR.replace( <?php echo e($options['id'] ?? 'editor1'); ?>,{
    // removeButtons: '',
    // removeButtons: 'PasteFromWord',     
    toolbarGroups: [{
          name: 'basicstyles',
          groups: ['basicstyles', 'cleanup']
    },{
      name: 'colors'
    }]
  } );
</script> 
<?php else: ?>
<script>
  // Replace the <textarea id="editor1"> with a CKEditor 4
  // instance, using default configuration.
  // https://ckeditor.com/docs/ckeditor4/latest/examples/removeformat.html
  CKEDITOR.replace( <?php echo e($options['id'] ?? 'editor1'); ?>,{
    
  } );
</script>
<?php endif; ?>



<?php /**PATH /home1/nhathhmd/public_html/laravel/demo/resources/views/components/editor.blade.php ENDPATH**/ ?>