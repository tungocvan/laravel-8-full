<?php    
    $category = $data['category'];      
    $parent = $data['parent'] ?? 0;  
    $key = $data['key'] ?? -1;     
    $id = request()->id ?? 0;
    $options = [
        'name' => [
            'name' => 'name',
            'title' => 'Tên',
            'value' => $data['editData'][$key]->name ?? old('name')
        ], 
        'slug' => [
            'name' => 'slug',
            'title' => 'Đường dẫn',
            'value' => $data['editData'][$key]->slug ?? old('slug')
        ],    
        'description' => [
            'title' => 'Mô tả',
            'name' => 'description',
            'value' => $data['description'] ?? old('description')
        ],
    ];
?>

    <div class="container">
        <div class="row">
            <div class="col-4">
                <div class="d-sm-flex justify-content-between mt-4">
                    <h4 class="mb-4">Thêm chuyên mục</h4>                       
                </div>
                <hr /> 
                    <form method="POST" action="<?php echo e(route('post.post-add-category')); ?>">
                    <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['name']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?> 
                <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputText::class, ['options' => $options['slug']]); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?> 
                
                <select class="form-select mb-2" aria-label="Default select" name="category[]">
                    <option selected="" value="0">Root</option>
                     <?php echo getCategoriesOptions(['data' => $category,  'parent' => $parent]); ?>

                </select>
                <?php if (isset($component)) { $__componentOriginalb47d2f1e8e342d38f8d0ab7380545b6422bef746 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputTextArea::class, ['options' => $options['description']]); ?>
<?php $component->withName('input-text-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb47d2f1e8e342d38f8d0ab7380545b6422bef746)): ?>
<?php $component = $__componentOriginalb47d2f1e8e342d38f8d0ab7380545b6422bef746; ?>
<?php unset($__componentOriginalb47d2f1e8e342d38f8d0ab7380545b6422bef746); ?>
<?php endif; ?>
                <div class="d-sm-flex justify-content-between mt-4">
                    <?php if($id): ?>
                          <input hidden type="text" name='id' value=<?php echo e($id); ?> />  
                          <button type="submit" class="btn btn-primary"> cập nhật chuyên mục</button> 
                    <?php else: ?>
                         <button type="submit" class="btn btn-primary"> Thêm chuyên mục</button> 
                    <?php endif; ?>
                                          
                </div>
                </form>
            </div>            
            <div class="col-8">
                <div class="d-sm-flex justify-content-between mt-4">
                      
                </div>
                <hr />
                <?php echo e(getCategoriesTable($data['data'])); ?> 
            </div>            
        </div>
    </div>
<?php /**PATH /var/www/laravel-8/modules/Post/Resources/views/phoenix/parts/category-content.blade.php ENDPATH**/ ?>