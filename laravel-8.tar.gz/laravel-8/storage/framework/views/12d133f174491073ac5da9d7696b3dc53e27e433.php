<?php          
  $title = $title ?? 'admin';    
  $module = $module ?? 'admin';        
?>

<?php $__env->startSection('cssHead'); ?>  
        <link rel="stylesheet" href="/phoenix/assets/css/line.css" />
        <link
        href="/phoenix/assets/css/theme-rtl.min.css"
        type="text/css"
        rel="stylesheet"
        id="style-rtl"
        />
        <link
        href="/phoenix/assets/css/theme.min.css"
        type="text/css"
        rel="stylesheet"
        id="style-default"
        />
        <link href="/phoenix/assets/css/app.css" rel="stylesheet" />        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        
        <link href="https://prium.github.io/phoenix/v1.10.0/vendors/dropzone/dropzone.min.css" rel="stylesheet" type="text/css" />
        
        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsHead'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>        
        <script src="/plugin/flatpickr/dist/flatpickr.min.js"></script>
<?php echo \Illuminate\View\Factory::parentPlaceholder('jsHead'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <?php echo $__env->make("$module::phoenix.$title",compact('module','action'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsFooter'); ?>        
        <script src="/phoenix/vendors/popper/popper.min.js"></script>                           
        <script src="/phoenix/vendors/bootstrap/bootstrap.min.js"></script>   
        <script src="/phoenix/vendors/fontawesome/all.min.js"></script>                         
        <script src="/phoenix/assets/js/app.js"></script>
        <script src="https://prium.github.io/phoenix/v1.10.0/vendors/dropzone/dropzone.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/nhathhmd/public_html/laravel/demo/modules/Groups/Resources/views/phoenix/phoenix.blade.php ENDPATH**/ ?>