<?php         
     $number = (string) rand(10,99);
     $name = $options['name'] ?? 'name_'.$number;
     $id =   $options['id'] ?? $name;
     $title= $options['title'] ?? '' ;      
     $value = $options['value'] ?? '';     
     $rows = $options['rows'] ?? 5;    
     $height =  $options['height'] ?? '160px';  
?>
<div class="form-floating mb-2">  
    <?php if($title !==''): ?>
        <label class="form-label mb-2" for="<?php echo e($name); ?>"><?php echo e(__($title)); ?></label>        
    <?php endif; ?>  
    <textarea style="height:<?php echo e($height); ?>" class="form-control pt-5  <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  rows="<?php echo e($rows); ?>" name="<?php echo e($name); ?>"  id="<?php echo e($id); ?>" <?php if($value !==''): ?> value="<?php echo e($value); ?>" <?php endif; ?> ><?php echo e($value); ?></textarea>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   
</div>


<?php /**PATH /home1/nhathhmd/public_html/laravel/demo/resources/views/components/input-text-area.blade.php ENDPATH**/ ?>