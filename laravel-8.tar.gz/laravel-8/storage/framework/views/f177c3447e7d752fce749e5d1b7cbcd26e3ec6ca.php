<?php
    //dd($data['data']['group']->name);
    $nameModule = $data['data']['group']->name ?? '';
    $modules = $data['data']['modules'];
    $group = $data['data']['group'];
    $roleListArr = $data['data']['roleListArr'];
    $roleArr = $data['data']['roleArr'];
    
?>
<h3>Phân quyền nhóm - <?php echo e($nameModule); ?></h3>
<form method="POST" action="<?php echo e(route('groups.post-permission',$group)); ?>">
    <table class="table">
        <thead>
          <tr>  
               <th width="15%">Modules</th>
               <th>Quyền</th>               
          </tr>
        </thead>
        <tbody>
    <?php if($modules->count() > 0): ?>
    
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($module->title); ?></td>
                <td>
                    <div class="row">
                        <?php if(!empty($roleListArr)): ?>
                          <?php $__currentLoopData = $roleListArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleName => $roleLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="col-2">
                                <label for="role_<?php echo e($module->name); ?>_<?php echo e($roleName); ?>">
                                    <input type="checkbox" name="role[<?php echo e($module->name); ?>][]" id="role_<?php echo e($module->name); ?>_<?php echo e($roleName); ?>" value="<?php echo e($roleName); ?>"
                                    <?php echo e(isRole($roleArr,$module->name,$roleName) ? 'checked':false); ?>

                                    />
                                    <?php echo e($roleLabel); ?>

                                </label>
                              </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        <?php endif; ?>
                        <?php if($module->name == 'Groups'): ?>
                            <div class="col-3">
                                <label for="role_<?php echo e($module->name); ?>_permission">
                                    <input type="checkbox" name="role[<?php echo e($module->name); ?>][]" id="role_<?php echo e($module->name); ?>_permission" value="permission" 
                                    <?php echo e(isRole($roleArr,$module->name,'permission') ? 'checked':false); ?>

                                />
                                Phân quyền
                                </label>
                            </div>
                        <?php endif; ?>
                    </div>
                </td>
    
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    <?php endif; ?>
    </tbody>
    </table>
    <button type="submit">Phân quyền</button>
    <?php echo csrf_field(); ?>
    </form><?php /**PATH /var/www/laravel-8/modules/Groups/Resources/views/phoenix/parts/permission-content.blade.php ENDPATH**/ ?>