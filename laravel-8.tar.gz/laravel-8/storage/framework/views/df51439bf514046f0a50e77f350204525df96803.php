<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />           
        <?php $__env->startSection('meta'); ?>                              
        <?php echo $__env->yieldSection(); ?> 
        <!-- Favicon icon-->
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <!-- Libs CSS -->        
        <?php $__env->startSection('cssHead'); ?>                              
        <?php echo $__env->yieldSection(); ?>  
        <?php $__env->startSection('jsHead'); ?>                              
        <?php echo $__env->yieldSection(); ?>          
    </head>
    <body>        
              <?php $__env->startSection('header'); ?>                              
              <?php echo $__env->yieldSection(); ?>             
              <?php $__env->startSection('main'); ?>                              
              <?php echo $__env->yieldSection(); ?> 
              <?php $__env->startSection('footer'); ?>                  
              <?php echo $__env->yieldSection(); ?>             
              <?php $__env->startSection('modal'); ?>                  
              <?php echo $__env->yieldSection(); ?>                            
              <?php $__env->startSection('jsFooter'); ?>   
              <?php echo $__env->yieldSection(); ?>              
    </body>
</html>
  <?php /**PATH /var/www/laravel-8/resources/views/layouts/master.blade.php ENDPATH**/ ?>