<?php
    //dd($data['data']);
?>
<?php if(session('msg')): ?>
    <div class="alert alert-outline-success"><?php echo e(session('msg')); ?></div>
<?php endif; ?> 
<h3>Danh sách nhóm</h3>
<hr />
<table class="table">
  <thead>
    <tr>             
         <th>ID</th>
         <th>Group Name</th>
         <th>Action</th>
         
    </tr>
  </thead>
  <tbody>
    <?php if(count($data['data']) > 0): ?>
      <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>             
        <td><?php echo e($item['id']); ?></td>
        <td><?php echo e($item['name']); ?></td>
        <td>
          <div class="row">
              <div class="col-3">
                <a href="<?php echo e(route('groups.permission',$item)); ?>">Phân quyền</a>                 
              </div>
              <div class="col-2"><a href="#">Sửa</a></div>
              <div class="col-2"><a href="#">Xóa</a></div>
          </div>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
  </tbody>
</table>
<script>        
    document.addEventListener('DOMContentLoaded', function(event) {
        
    });
</script><?php /**PATH /home1/nhathhmd/public_html/laravel/demo/modules/Groups/Resources/views/phoenix/parts/groups-content.blade.php ENDPATH**/ ?>