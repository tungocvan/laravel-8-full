<form action="/api/upload-file" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="file">
    <button type="submit">Upload</button>
</form><?php /**PATH /home1/nhathhmd/public_html/laravel/demo/resources/views/components/upload-file.blade.php ENDPATH**/ ?>