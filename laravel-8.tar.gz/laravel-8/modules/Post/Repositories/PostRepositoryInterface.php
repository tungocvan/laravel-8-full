<?php
namespace Modules\Post\Repositories;
use App\Repositories\RepositoryInterface;
interface PostRepositoryInterface extends RepositoryInterface
{
    public function getPost();
}