<h2>ADMIN CONTENT</h2>
<iframe src="https://www.digmandarin.com/tools/pinyin.html?show_embed_button=true" width="100%" height="482px"></iframe>