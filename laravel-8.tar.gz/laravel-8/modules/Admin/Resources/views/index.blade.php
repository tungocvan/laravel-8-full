@if (session('msg'))
    <div class="alert alert-outline-success">{{session('msg')}}</div>
@endif 
<h3>{{$title}}</h3>
<hr />

<script>        
    document.addEventListener('DOMContentLoaded', function(event) {
        
    });
</script>
 