<footer>
    <h4>FOOTER HAMADA</h4>
</footer>
